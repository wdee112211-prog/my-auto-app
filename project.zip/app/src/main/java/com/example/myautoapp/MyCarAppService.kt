package com.example.myautoapp

import android.content.Intent
import androidx.car.app.CarAppService
import androidx.car.app.Session
import androidx.car.app.validation.HostValidator

class MyCarAppService : CarAppService() {

    // للتجربة فقط. قبل النشر على جوجل بلاي نغيّرها للقائمة الرسمية.
    override fun createHostValidator(): HostValidator =
        HostValidator.ALLOW_ALL_HOSTS_VALIDATOR

    override fun onCreateSession(): Session = MySession()
}

class MySession : Session() {
    override fun onCreateScreen(intent: Intent) = MainScreen(carContext)
}
