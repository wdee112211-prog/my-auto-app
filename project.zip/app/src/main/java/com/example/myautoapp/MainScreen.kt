package com.example.myautoapp

import androidx.car.app.CarContext
import androidx.car.app.Screen
import androidx.car.app.model.Action
import androidx.car.app.model.MessageTemplate
import androidx.car.app.model.Template

class MainScreen(carContext: CarContext) : Screen(carContext) {

    override fun onGetTemplate(): Template =
        MessageTemplate.Builder("أهلاً! التطبيق شغال على شاشة السيارة.")
            .setTitle("تطبيقي")
            .setHeaderAction(Action.APP_ICON)
            .build()
}
